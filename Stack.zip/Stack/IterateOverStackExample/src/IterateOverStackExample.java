import java.util.Iterator;
import java.util.ListIterator;
import java.util.Stack;

 


public class IterateOverStackExample {
public static void main(String[] args) {
	Stack<String> stackOfPlates=new Stack<>();
	stackOfPlates.add("Plate 1");
	stackOfPlates.add("Plate 2");
	stackOfPlates.add("Plate 3");
	stackOfPlates.add("Plate 4");
	
	System.out.println("\n=== Iterate over a Stack using Java 8 forEach() method===");
	stackOfPlates.forEach(plate -> {
		System.out.println(plate);
	});
	
	System.out.println("\n===Iterate over a Stack using Iterator()===");
	Iterator<String> platesIterator=stackOfPlates.iterator();
	while(platesIterator.hasNext()){
		String plate=platesIterator.next();
		System.out.println(plate);
	}
	System.out.println("\n===Iterate over a Stack using Iterator() and Java8 forEachRemaining() method===");
	platesIterator=stackOfPlates.iterator();
	while(platesIterator.hasNext()){
		String plate=platesIterator.next();
		System.out.println(plate);
	}
	
	System.out.println("\n===Iterate over a stack from Top to Bottom using listIterator()===");
ListIterator<String> platesListIterator=stackOfPlates.listIterator(stackOfPlates.size());
while(platesListIterator.hasPrevious()){
	String plate=platesListIterator.previous();
	System.out.println(plate);
}

System.out.println(stackOfPlates.pop());
System.out.println(stackOfPlates.get(0));
stackOfPlates.set(0, "I am not a plate");
System.out.println("\n===Iterate over a stack from Top to Bottom using listIterator()===");
ListIterator<String> platesListIterator1=stackOfPlates.listIterator(stackOfPlates.size());
while(platesListIterator1.hasPrevious()){
	String plate=platesListIterator1.previous();
	System.out.println(plate);
}


}
}
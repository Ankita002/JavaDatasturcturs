package s1;

import java.util.Stack;

public class Test {

	static void stack_push(Stack<Integer> stack){
		for(int i=0;i<5;i++){
			stack.push(i);
		}
	}
	static void stack_pop(Stack<Integer> stack){
	System.out.println("Pop :");
	for(int i=0;i<5;i++){
		Integer y=(Integer) stack.pop();
		System.out.println(y);
	}
	
	}
	static void stack_peek(Stack<Integer> stack){
		Integer y=(Integer) stack.peek();
		System.out.println("Element on the top of stack "+y);
	}
	static void stack_search(Stack<Integer> stack,int element){
		Integer pos=(Integer)stack.search(element);
		if(pos==-1){
			System.out.println("Element not found");
		}
		else{
			System.out.println("Element is found at position "+pos);
			
		}
	}
	
	public static void main(String[] args) {
		Stack<Integer> stack=new Stack<Integer>();
		stack_push(stack);
		stack_pop(stack);
		stack_push(stack);
		stack_peek(stack);
		stack_search(stack,4);
		System.out.println(stack.empty());
		stack_search(stack,6);
		stack_pop(stack);
		System.out.println(stack.empty());
		
		
	}
	
}

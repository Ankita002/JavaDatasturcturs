import java.util.Iterator;
import java.util.PriorityQueue;


public class Main {
	public static void main(String[] args) {
		
	
PriorityQueue<String> q=new PriorityQueue<>();
q.add("a");
q.add("b");
q.add("c");
q.add("d");
q.add("e");
System.out.println("head:"+q.element());
System.out.println("head:"+q.peek());
System.out.println("Iterating queue elements");
Iterator itr=q.iterator();
while(itr.hasNext()){
	System.out.println(itr.next());
	
}
System.out.println(q.remove());
System.out.println(q.poll());
System.out.println("after removing two elements");
Iterator<String> itr2=q.iterator();
while(itr2.hasNext()){
	System.out.println(itr2.next());
}
}
}
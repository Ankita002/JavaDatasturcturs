package p2;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
public static void main(String[] args) {
	Queue<Integer> q=new LinkedList<>();
	for(int i=0;i<5;i++){
		q.add(i);
	}
	System.out.println("Elements of Queue-"+q);
	
	int removedele =q.remove();
	System.out.println("Removed element-"+removedele);
	System.out.println(q);
	int head=q.peek();
	System.out.println("Head of queue-"+head);
	int size=q.size();
     System.out.println("size of queue-"+size);
     int removedele1 =q.remove();
 	System.out.println("Removed element-"+removedele1);
 	System.out.println(q);
 	int head1=q.peek();
 	System.out.println("Head of queue-"+head1);
}
}

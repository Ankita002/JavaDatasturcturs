package p5;

public class Student {
public int roll_no;
public String name;
Student(int roll_no,String name){
	this.roll_no=roll_no;
	this.name=name;
}


}

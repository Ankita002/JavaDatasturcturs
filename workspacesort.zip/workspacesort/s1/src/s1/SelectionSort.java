package s1;

public class SelectionSort {
void sort(int arr[]){
	int n=arr.length;
	for(int i=0;i<n-1;i++){
		int min_max=i;
		for(int j=i+1;j<n;j++){
			if(arr[j]<arr[min_max])
				min_max=j;
		}
			int temp=arr[min_max];
			arr[min_max]=arr[i];
			arr[i]=temp;
			
		}
	
}
	
void printArray(int arr[])
{
	int n=arr.length;
	for(int i=0;i<n;i++){
		System.out.println(arr[i]);
	}
	System.out.println();
}
		
public static void main(String[] args) {
	SelectionSort on=new SelectionSort();
	int arr[]={64,25,12,22,11
			};
	on.sort(arr);
	System.out.println("Sorted array:");
	on.printArray(arr);
	
	
	
	
	
	
	
	
}




	
	
	
	
	
	
}
